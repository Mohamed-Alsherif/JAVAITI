package com.example.Wuzzuf_Jobs_App;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class Hello_App extends Application 
{

}