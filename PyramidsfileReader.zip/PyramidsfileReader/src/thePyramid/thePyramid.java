package thePyramid;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.DoubleStream;
import java.util.stream.IntStream;

public class thePyramid 
{
    public static void main(String[] args) {
        
            String filepath="pyramids.csv";
            pyramids pd=new pyramids();
            pyramidsDAO pDd= new pyramidsDAO();
            List<pyramids>  pyramid = (List<pyramids>) pDd.readpyramidFromCSV(filepath);
            List<Float> heights =pyramid.stream()
                                     .map(p->p.getHeight() )         
                                     .collect(Collectors.toList()); 
            
            double Avarage = (heights.stream().mapToDouble(i -> i.doubleValue()).sum())/(heights.stream().mapToDouble(i -> i.doubleValue()).count());
            System.out.print("this is avarage of arr "+Avarage );
            long count =heights.stream().mapToDouble(i -> i.doubleValue()).count();
            List<Float> sorted_height =pyramid.stream().map(p->p.getHeight() ).sorted().collect(Collectors.toList()); 
            System.out.println("This is sorted list " + sorted_height );

  
                  
            List<Float> sorted_heightright =pyramid.stream().map(p->p.getHeight() ).sorted().collect(Collectors.toList()).subList((sorted_height.size()/2)+2,sorted_height.size() );
            List<Float> sorted_heightleft =pyramid.stream().map(p->p.getHeight() ).sorted().collect(Collectors.toList()).subList(0, (sorted_height.size()/2));
            System.out.println("Left side List = "+sorted_heightleft);
            System.out.println("right side List = "+sorted_heightright);
            
            thePyramid m=new thePyramid();
            double large_median= m.returnmedian(sorted_height);
            System.out.println("from function return Large Median : "+large_median);

            double left_median= m.returnmedian(sorted_heightleft);
            System.out.println("from function return Left Median : "+left_median);
                  
            
            double right_median= m.returnmedian(sorted_heightright);
            System.out.println("from function return Right Median : "+right_median);      
       
    
    }
     public Double returnmedian (List<Float> x){
         double count= x.size();
          if (count %2==0){
             double f1=x.get(((x.size()-1)/2));
             double f2=x.get(x.size()/2);
             double median = (f1+f2)/2;
             return median;
            
        }else{
             
             double median=x.get(x.size()/2);
             System.out.println("median of odd number ="+median);
             return median;

         }
         
        
    }
    
 
}

