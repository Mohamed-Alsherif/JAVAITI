package thePyramid;
import java.io.BufferedReader;
import java.io.File;  // Import the File class
import java.io.FileNotFoundException;  // Import this class to handle errors
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner; // Import the Scanner class to read text files
import java.util.stream.Collectors;
//import jdk.dynalink.linker.support.Guards;

public class pyramidsDAO {
     pyramidsDAO () {
   
     }
     
     public List<pyramids> readpyramidFromCSV (String filename)
     {
         List<pyramids> mypyramid=new ArrayList<pyramids>();        
         try {
             FileReader fr =new FileReader(filename);
             BufferedReader br =new BufferedReader(fr);
             List<String> mylines=br.lines().collect(Collectors.toList());
//             System.out.println(mylines.size());
              mylines.remove(0);
                
             
               Iterator iter = mylines.iterator();
          while (iter.hasNext()) {
        
               String lineparts  []=((String)iter.next()).split(",");
               String  pharoah_name=lineparts[0];
               String moden_name=lineparts[1];
               String site=lineparts[2];
               String h= lineparts[7];
               float height=1;
               if(h == null || h.isEmpty()){
                   height= 1;              
                 
               }else {
              
                 height= Float.parseFloat(h);
//                System.out.println(height);
               }
            pyramids pyramids=new pyramids(pharoah_name,moden_name,site,height);
            
            mypyramid.add(pyramids);
            

          }
        } catch (IOException e) {
          System.out.println("An error occurred.");
          e.printStackTrace();
        }

         return mypyramid;
         
     }
     public pyramids creatPyramid()
     {
         
         return null;
         
     }


}